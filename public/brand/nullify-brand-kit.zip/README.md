# Nullify brand kit

This kit contains the Nullify logo files, colors and type rules.

## Files

| File | Use |
|---|---|
| `svg/icon-color.svg` | Main icon. Use on a white background. |
| `svg/icon-color-on-dark.svg` | Main icon. Use on a dark background. |
| `svg/icon-black.svg`, `svg/icon-white.svg` | One-color icon. Use when you cannot print red. |
| `svg/wordmark-black.svg`, `svg/wordmark-white.svg` | Name only. |
| `svg/lockup-color.svg`, `svg/lockup-color-on-dark.svg` | Icon and name together. Use this first. |
| `svg/n1-black.svg`, `svg/n1-white.svg` | N1 monogram. Use for avatars and small marks. |
| `svg/favicon.svg` | Icon with thick lines. Use at 64 px and smaller. |
| `png/` | PNG copies at 512 px, and favicons at 32, 180 and 512 px. |
| `tokens.css`, `tokens.json` | Colors and type as code. |

## The icon

The icon is an outlined N with a red slash through it. The slash means "null". Keep the slash red when you use the color version.

- Keep clear space around the icon. The minimum is half the icon width.
- Do not fill the outline.
- Do not rotate, stretch or add effects.
- Do not change the slash color to a color other than red, black or white.
- At 64 px and smaller, use `favicon.svg`. The thin lines of the main icon become faint at small sizes.

## Colors

| Name | Hex | Use |
|---|---|---|
| Ink | `#0B0B0C` | Text, outline, wordmark |
| Paper | `#FFFFFF` | Background |
| Red | `#ED1C24` | The slash and strike lines only |
| Red text | `#B3121A` | Red text on white |
| Muted | `#5B5F66` | Secondary text |
| Line | `#E4E4E6` | Dividers and borders |

Use red only for one mark on a page. Do not use red for large areas.

Do not use `#ED1C24` for small text on white. The contrast is too low. Use `#B3121A`.

## Type

- Font: Helvetica Neue. If it is not available, use Helvetica, then Arial.
- Headings: weight 800, italic, letter spacing -0.035em.
- Body: weight 400, 17 px, line height 1.6.

## History

The original icon and wordmark are from 2020. The 2026 kit keeps the same N, slash and wordmark. It changes these items:

- The icon is an outline. The solid version looked like a block at small sizes.
- There is a thick-line favicon for small sizes.
- The files have no editor metadata.
- The colors and type rules are written down.

The old `brand_pkg` folder in this repo was the BiscuitHost kit. It was not a Nullify kit. This kit replaces it.
